./PhoenixMiner -pool stratum-etc.antpool.com:8008  -wal etcuser -worker rgz -epsw x -mode 1 -Rmode 1 -log 0 -mport 0 -etha 0 -retrydelay 1 -ftime 55 -tt 79 -tstop 89 -asm 2 -coin etc
pause

